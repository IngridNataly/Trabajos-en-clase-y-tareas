<?php

$valor = $_POST ["valor"];
$edad = $_POST ["edad"];
$descuento1 = $valor * 0.20;
if($valor <=0 or $edad <=0 
)
 {print "error";
}
 else { if ($edad < 60) {  print "el total a pagar es". $valor;
  
} else { $DESCUENTO = $valor - $descuento1;
    print "el total a pagar es:". $DESCUENTO;
}
}


?>
