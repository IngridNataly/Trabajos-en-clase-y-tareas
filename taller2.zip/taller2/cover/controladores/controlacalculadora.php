<?php

$numeroa= $_POST["numeroa"];
$numerob= $_POST["numerob"];
$operaciones=$_POST["operaciones"];
$suma= $numeroa+$numerob;
$resta= $numeroa-$numerob;
$multiplicacion= $numeroa*$numerob;
$division= $numeroa/$numerob;
if($operaciones==1) {
  echo "la operacion es". $suma;
}

if ($operaciones==2) {
  echo "la operacion es". $resta;
}

if ($operaciones==3) {
  echo "la operacion es". $multiplicacion;
}
  
if ($operaciones==4) {
  echo "la operacion es". $division;
}

