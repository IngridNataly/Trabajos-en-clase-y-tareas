<?php
$churros = $_POST ["churro"];
$valorchurro="1500";
$multiplicacion= $churros*$valorchurro;
if ($churros <=0 ) {
  echo "error";}
  else{$multiplicacion= $churros*$valorchurro;
    print "el valor es ". $multiplicacion;
  }



?>