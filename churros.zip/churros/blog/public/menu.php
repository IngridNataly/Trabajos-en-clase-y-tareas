<nav class="nav nav-underline justify-content-between">
      <a class="nav-item nav-link link-body-emphasis active" href="inicio.php">inicio</a>
      <a class="nav-item nav-link link-body-emphasis" href="reservar.php">reservar</a>
      <a class="nav-item nav-link link-body-emphasis" href="vender.php">vender</a>
      <a class="nav-item nav-link link-body-emphasis" href="consultarsaldo.php">consultar saldo</a>
     
    </nav>