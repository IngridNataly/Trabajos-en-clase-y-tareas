<?php

$nombrePersona= $_POST ["nombre"];
$documento= $_POST["documento"];
$fecha_nacimiento=$_POST["fecha"];
$celular=$_POST ["celular"];
print "el nombre es: ".$nombrePersona;
print "el documento es: ".$documento;
print "la fecha de nacimiento es:".$fecha_nacimiento;
print "el celular es:".$celular;
?>