 <ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="electivas.php">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                electivas
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="prematricula.php">
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                pre-matrícula
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="matricula.php">
                <svg class="bi"><use xlink:href="#cart"/></svg>
                matrícula
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="horario.php">
                <svg class="bi"><use xlink:href="#people"/></svg>
                horario
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="reportes.php">
                <svg class="bi"><use xlink:href="#graph-up"/></svg>
                reportes
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="consultamaterias.php">
                <svg class="bi"><use xlink:href="#puzzle"/></svg>
                consulta Materias
              </a>
            </li>
          </ul>