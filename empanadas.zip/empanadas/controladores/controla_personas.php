<?php

$documento = $_POST ["documento"];
$empanadas = "2000";
if ($documento <=0 ) {
    print "error";} 
    else { $valor = $documento * $empanadas;
        print "el valor es:" . $valor; 
}


?>
